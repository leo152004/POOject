import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Ecra de proximo nivel
 * 
 * @Lucas Waddle - 
 */
public class NextLevel extends Actor
{
}
