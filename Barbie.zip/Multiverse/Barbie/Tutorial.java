import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Tutorial dos controlos no jogo
 * 
 * @Leandro Gonçalves - 2123522
 */
public class Tutorial extends Actor
{
}
