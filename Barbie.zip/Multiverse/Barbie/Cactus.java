import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Um cacto para decoraçao
 * 
 * @Lucas Waddlle 
 */
public class Cactus extends LevelObjects
{
    public void act()
    {
        gravity();
        atGround();
    }
}
