import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Icon do jogo
 * 
 * @Leandro Gonçalves - 2123522
 */
public class Icon extends Actor
{
    //Hello
}
