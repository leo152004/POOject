import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * um Objeto usado para que o player apenas conte como chao o topo das plataformas e nao todo o objeto da classe Stone
 * 
 * @Leandro Gonçalves - 2123522
 */
public class Ground extends LevelObjects
{
    public void act()
    {
        descendo();
    }
}
