import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Apenas para categorizaçao destes objetos
 * 
 * @Leandro Gonçalves
 */
public class LevelObjects extends Gravity
{
}
