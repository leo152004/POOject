import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Imagem que indica como passar para o nivel 0
 * 
 * @Leandro Gonçalves - 2123522
 */
public class Tutorial2 extends Actor
{
}
