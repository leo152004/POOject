import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Textura usada para as plataformas que sao usadas para saltar e tambem usada para o chao
 * 
 * @Lucas Waddlle - 
 */
public class Stone extends LevelObjects

{
    public void act()
    {
        descendo();
    }
}
