import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Planta para decoraçao
 * 
 * @Lucas Waddlle - 
 */
public class Plant extends LevelObjects
{
    public void act()
    {
        gravity();
        atGround();
    }
}
